"""Data-access layer for the automation engine.

Pure query helpers — no transactions, no audit, no commits. Leaf
module; never imports a ``service.py``. Single-file per the locked
layered convention (manager spec 2026-06-25).

Step 2 fills in the trigger-side reads (list / get / matcher). Step
4 will extend with run helpers (insert_run + idempotency check +
list_runs for the run-history endpoint).

Tenant scoping is applied automatically by the ``do_orm_execute``
listener on every SELECT, but consumers SHOULD also pass ``org_id``
explicitly in the WHERE clause as a belt-to-the-suspenders defense
— Celery tasks + scripts that forget to set ``RequestContext.org_id``
still get correct results.
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from src.app.core.automation.models import (
    AutomationRun,
    AutomationRunStatus,
    AutomationTrigger,
)
from src.app.core.conversations.models import ConversationChannel


async def get_trigger(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    trigger_id: uuid.UUID,
) -> AutomationTrigger | None:
    """Resolve a trigger by its UUID PK. ``None`` if missing or
    cross-tenant (callers translate to :class:`TriggerNotFound`)."""
    result = await session.execute(
        select(AutomationTrigger).where(
            AutomationTrigger.id == trigger_id,
            AutomationTrigger.org_id == org_id,
        )
    )
    return result.scalar_one_or_none()


async def get_trigger_by_name(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    name: str,
) -> AutomationTrigger | None:
    """Case-insensitive name lookup — drives the duplicate-name
    rejection at create + update time. Uses the functional unique
    index ``uq_automation_triggers_org_lower_name`` from Step 1."""
    result = await session.execute(
        select(AutomationTrigger).where(
            AutomationTrigger.org_id == org_id,
            func.lower(AutomationTrigger.name) == name.strip().lower(),
        )
    )
    return result.scalar_one_or_none()


async def list_triggers(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    event_type: str | None = None,
    enabled: bool | None = None,
    channel: ConversationChannel | None = None,
    q: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[AutomationTrigger], int]:
    """Filterable + paginated list. ``q`` matches against ``name``
    or ``event_type`` (case-insensitive). Returns ``(rows, total)``.

    ``order by id ASC`` keeps the matcher deterministic — Step 4's
    dispatcher relies on stable trigger ordering when an event has
    multiple matching triggers + we want the run-rows to insert in
    a consistent sequence."""
    base = select(AutomationTrigger).where(AutomationTrigger.org_id == org_id)

    if event_type is not None:
        base = base.where(AutomationTrigger.event_type == event_type)
    if enabled is not None:
        base = base.where(AutomationTrigger.enabled.is_(enabled))
    if channel is not None:
        base = base.where(AutomationTrigger.channel == channel)
    if q:
        pattern = f"%{q.lower()}%"
        base = base.where(
            or_(
                func.lower(AutomationTrigger.name).like(pattern),
                func.lower(AutomationTrigger.event_type).like(pattern),
            )
        )

    total = (await session.execute(select(func.count()).select_from(base.subquery()))).scalar_one()

    rows = (
        (
            await session.execute(
                base.order_by(AutomationTrigger.id.asc()).offset(offset).limit(limit)
            )
        )
        .scalars()
        .all()
    )
    return list(rows), int(total)


async def match_enabled_triggers(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    event_type: str,
) -> list[AutomationTrigger]:
    """Hot-path matcher query the dispatcher hits on every event
    publish. Returns every enabled trigger for ``(org_id,
    event_type)`` in deterministic ``id ASC`` order.

    Condition evaluation happens upstream in
    :func:`core.automation.conditions.evaluate` so this query stays
    a simple index-covered SELECT — the
    ``ix_automation_triggers_org_event_enabled`` covering index from
    Step 1 makes it O(log n + match-count)."""
    result = await session.execute(
        select(AutomationTrigger)
        .where(
            AutomationTrigger.org_id == org_id,
            AutomationTrigger.event_type == event_type,
            AutomationTrigger.enabled.is_(True),
        )
        .order_by(AutomationTrigger.id.asc())
    )
    return list(result.scalars().all())


def add_trigger(session: AsyncSession, trigger: AutomationTrigger) -> AutomationTrigger:
    """Stage a new trigger row in the unit-of-work. Service commits."""
    session.add(trigger)
    return trigger


async def find_by_migrated_workflow_id(
    session: AsyncSession,
    *,
    workflow_id: uuid.UUID,
) -> AutomationTrigger | None:
    """Reverse-lookup: given a workflow id, return the source
    automation trigger whose ``migrated_to_workflow_id`` points at it.

    Reads the FK column added by migration
    ``0175_automation_migrated_fk``. Used by the redirect resolver
    (Step 3 of workflows-absorb-automation) — but also useful for
    diagnostic + rollback tooling. Returns ``None`` when the workflow
    isn't a mirror of any automation (native workflow, or the FK was
    cleared)."""
    result = await session.execute(
        select(AutomationTrigger).where(
            AutomationTrigger.migrated_to_workflow_id == workflow_id,
        )
    )
    return result.scalar_one_or_none()


def set_migrated_to(
    session: AsyncSession,
    *,
    automation: AutomationTrigger,
    workflow_id: uuid.UUID,
) -> AutomationTrigger:
    """Stage the ``enabled = false`` + ``migrated_to_workflow_id``
    flip on the source automation.

    Mutation-in-place — the session already tracks the row. Service
    commits. Kept in the DAL (rather than the service) so the same
    helper can be called from ad-hoc scripts / rollback tools without
    dragging in service-layer imports."""
    automation.enabled = False
    automation.migrated_to_workflow_id = workflow_id
    return automation


# --- tbl_automation_runs ------------------------------------------------


async def get_run(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    run_id: uuid.UUID,
) -> AutomationRun | None:
    """Resolve a single run by id. ``None`` if missing or cross-tenant."""
    result = await session.execute(
        select(AutomationRun).where(
            AutomationRun.id == run_id,
            AutomationRun.org_id == org_id,
        )
    )
    return result.scalar_one_or_none()


async def get_run_by_id_unscoped(
    session: AsyncSession, *, run_id: uuid.UUID
) -> AutomationRun | None:
    """Tenant-agnostic lookup — Celery worker tasks call this
    because they don't carry a ``RequestContext``. Sets the org
    context internally before reading; safe to use ONLY from the
    Celery delivery path."""
    result = await session.execute(select(AutomationRun).where(AutomationRun.id == run_id))
    return result.scalar_one_or_none()


async def find_run_by_event_id(
    session: AsyncSession,
    *,
    trigger_id: uuid.UUID,
    event_id: str,
) -> AutomationRun | None:
    """Idempotency check — returns the prior run if the same
    publisher event already fired for this trigger. The dispatcher
    short-circuits when a row exists so at-least-once delivery
    doesn't double-send.

    Backed by the unique partial index
    ``uq_automation_runs_trigger_event_id`` from migration 0128."""
    result = await session.execute(
        select(AutomationRun).where(
            AutomationRun.trigger_id == trigger_id,
            AutomationRun.event_id == event_id,
        )
    )
    return result.scalar_one_or_none()


def add_run(session: AsyncSession, run: AutomationRun) -> AutomationRun:
    """Stage a new run row in the unit-of-work. Dispatcher commits."""
    session.add(run)
    return run


async def list_runs(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    trigger_id: uuid.UUID | None = None,
    contact_id: uuid.UUID | None = None,
    status: AutomationRunStatus | None = None,
    since: datetime | None = None,
    limit: int = 50,
    offset: int = 0,
) -> tuple[list[AutomationRun], int]:
    """Filterable + paginated run history. Drives the Step-9 UI's
    "what fired for this trigger" view + the per-contact timeline
    (filter by ``contact_id``).

    ``order by scheduled_at DESC`` so newest fires sit at the top —
    matches the partial index from Step 1
    (``ix_automation_runs_trigger_scheduled_desc``)."""
    base = select(AutomationRun).where(AutomationRun.org_id == org_id)

    if trigger_id is not None:
        base = base.where(AutomationRun.trigger_id == trigger_id)
    if contact_id is not None:
        base = base.where(AutomationRun.contact_id == contact_id)
    if status is not None:
        base = base.where(AutomationRun.status == status)
    if since is not None:
        base = base.where(AutomationRun.scheduled_at >= since)

    total = (await session.execute(select(func.count()).select_from(base.subquery()))).scalar_one()

    rows = (
        (
            await session.execute(
                base.order_by(AutomationRun.scheduled_at.desc()).offset(offset).limit(limit)
            )
        )
        .scalars()
        .all()
    )
    return list(rows), int(total)


async def list_recent_event_payloads(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    event_type: str,
    since: datetime,
    limit: int = 501,
) -> list[dict]:
    """Pull recent ``event_payload`` JSONBs for the matched-events
    preview (``tasks/automation-conditions/`` Step 5).

    Joins ``tbl_automation_runs`` to ``tbl_automation_triggers`` on
    ``trigger_id`` so the caller can filter by the ORIGINATING event
    type — runs don't carry ``event_type`` themselves. Returns the
    payloads (not full ``AutomationRun`` rows) since the caller only
    needs them for the in-memory evaluator sweep.

    Newest-first ordering matches the operator's intuition ("what
    happened in the last week?"). ``limit`` defaults to 501 so the
    service can detect the "truncated" case cleanly — if 501 rows
    come back, the org has more than 500 in the window and the
    preview response flips ``truncated=true``.

    NOTE: this reflects only events that already triggered at least
    one automation (runs table = post-dispatch record). A brand-new
    event type with no active triggers reads 0 here — the service
    reports ``source='none'`` in that case so the frontend can render
    the "no historical events available for preview" hint honestly
    rather than a misleading zero-count.
    """
    stmt = (
        select(AutomationRun.event_payload)
        .join(AutomationTrigger, AutomationTrigger.id == AutomationRun.trigger_id)
        .where(
            AutomationRun.org_id == org_id,
            AutomationTrigger.event_type == event_type,
            AutomationRun.scheduled_at >= since,
        )
        .order_by(AutomationRun.scheduled_at.desc())
        .limit(limit)
    )
    result = await session.execute(stmt)
    return [row for row in result.scalars().all()]


async def count_marketing_runs_for_contact(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    contact_id: uuid.UUID,
    since: datetime,
) -> int:
    """Count marketing-category automation runs sent to a contact in
    the rolling ``since → now`` window. Powers the Step-13
    frequency-cap send-guard check.

    A run counts only when:

      * its status is ``sent`` or ``dispatched`` (i.e. the message
        actually went out — queued + skipped + failed don't count
        toward the cap)
      * its ``completed_at`` (for ``sent``) or ``dispatched_at``
        (for ``dispatched`` but not yet completed) is at or after
        ``since``
      * the trigger's template has ``category='marketing'`` (joined
        via ``trigger.template_id → tbl_message_templates.category``)

    Backed by the partial index
    ``ix_automation_runs_contact_completed`` from migration 0134.
    """
    from src.app.core.templates.models import (
        MessageTemplate,
        TemplateCategory,
    )

    stmt = (
        select(func.count())
        .select_from(AutomationRun)
        .join(
            AutomationTrigger,
            AutomationTrigger.id == AutomationRun.trigger_id,
        )
        .join(
            MessageTemplate,
            MessageTemplate.id == AutomationTrigger.template_id,
        )
        .where(AutomationRun.org_id == org_id)
        .where(AutomationRun.contact_id == contact_id)
        .where(MessageTemplate.category == TemplateCategory.marketing)
        .where(
            AutomationRun.status.in_(
                (
                    AutomationRunStatus.sent,
                    AutomationRunStatus.dispatched,
                )
            )
        )
        .where(
            or_(
                AutomationRun.completed_at >= since,
                AutomationRun.dispatched_at >= since,
            )
        )
    )
    return int((await session.execute(stmt)).scalar_one())


__all__ = [
    "add_run",
    "add_trigger",
    "count_marketing_runs_for_contact",
    "find_run_by_event_id",
    "get_run",
    "get_run_by_id_unscoped",
    "get_trigger",
    "get_trigger_by_name",
    "list_runs",
    "list_triggers",
    "match_enabled_triggers",
]
