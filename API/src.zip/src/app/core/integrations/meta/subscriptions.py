"""Read + write helpers around Meta Pages and Lead-Form subscriptions.

Four operations, all thin wrappers around `MetaGraphClient`:

  - `list_pages(client)` — `GET /me/accounts`. Returns every Page the
    OAuth user manages. Backs the Settings UI's Page picker. Each
    page comes back with its own `access_token` (the Page token); we
    don't persist these, callers re-fetch every time they need to act
    on a Page.

  - `list_lead_forms_for_page(client, page_id, page_token)` —
    `GET /{page_id}/leadgen_forms`. Lists the Lead Forms attached to
    that Page. Status filter for ACTIVE forms only.

  - `subscribe_page(client, page_id, page_token)` —
    `POST /{page_id}/subscribed_apps` with `subscribed_fields=leadgen`.
    After this returns 200, Meta starts delivering lead events to our
    webhook URL (configured ONCE per environment in the Meta app
    dashboard, NOT per integration — that's how Meta's webhook model
    works).

  - `unsubscribe_page(client, page_id, page_token)` — symmetric
    `DELETE /{page_id}/subscribed_apps`. Stops deliveries for that
    Page. Doesn't touch other Pages on the same integration.

Both Facebook and Instagram Lead Ads ride the same `leadgen` webhook
field, so there's no parallel Instagram code path.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.app.core.integrations.crypto import encrypt
from src.app.core.integrations.meta.api_client import MetaGraphClient
from src.app.core.integrations.meta.models import MetaPageToken


@dataclass(frozen=True, slots=True)
class MetaPage:
    """One entry from `/me/accounts`. `access_token` is the per-Page
    token derived from the user token — needed for every subsequent
    Page-scoped call (list forms, subscribe, unsubscribe)."""

    page_id: str
    name: str
    access_token: str
    category: str | None = None


@dataclass(frozen=True, slots=True)
class MetaLeadForm:
    """One entry from `/{page_id}/leadgen_forms`. `status` is
    typically `ACTIVE` or `ARCHIVED` — Owner pickers should default
    to filtering out archived forms but we don't enforce it here."""

    form_id: str
    name: str
    status: str
    page_id: str


async def list_pages(client: MetaGraphClient) -> list[MetaPage]:
    """Every Page the OAuth user manages. Usually 1-5 for a small
    retailer; can be 100+ for a multi-brand operator (Business Manager).

    Pagination: Meta returns `paging.next` for >25 results. v1 takes
    the first page only — picker UI will show "showing first 25, use
    Business Manager to refine if more". When orgs hit this, we add
    cursor iteration in a follow-up small task.
    """
    body = await client.get(
        "/me/accounts",
        params={"fields": "id,name,access_token,category"},
    )
    raw = body.get("data") or []
    pages: list[MetaPage] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        page_id = item.get("id")
        token = item.get("access_token")
        name = item.get("name")
        if not page_id or not token or not name:
            continue
        pages.append(
            MetaPage(
                page_id=str(page_id),
                name=str(name),
                access_token=str(token),
                category=item.get("category"),
            )
        )
    return pages


async def list_lead_forms_for_page(
    client: MetaGraphClient,
    *,
    page_id: str,
    page_token: str,
) -> list[MetaLeadForm]:
    """Lead Forms on a single Page. `page_token` is the Page-scoped
    access_token from `list_pages` (NOT the user token) — Meta
    requires it for this endpoint."""
    body = await client.get(
        f"/{page_id}/leadgen_forms",
        params={"fields": "id,name,status"},
        access_token=page_token,
    )
    raw = body.get("data") or []
    forms: list[MetaLeadForm] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        form_id = item.get("id")
        if not form_id:
            continue
        forms.append(
            MetaLeadForm(
                form_id=str(form_id),
                name=str(item.get("name") or ""),
                status=str(item.get("status") or "UNKNOWN"),
                page_id=page_id,
            )
        )
    return forms


async def subscribe_page(
    client: MetaGraphClient,
    *,
    page_id: str,
    page_token: str,
) -> bool:
    """POST `/{page_id}/subscribed_apps` with `subscribed_fields=
    leadgen`. After this returns 200, Meta delivers lead events on
    every Lead Form attached to this Page to our webhook.

    Returns True on Meta's `{"success": true}` response. Caller is
    responsible for caching the Page token via `upsert_page_token`
    once Meta confirms — the worker needs the cache to fetch lead
    details when webhooks arrive."""
    body = await client.post(
        f"/{page_id}/subscribed_apps",
        params={"subscribed_fields": "leadgen"},
        access_token=page_token,
    )
    return bool(body.get("success"))


async def unsubscribe_page(
    client: MetaGraphClient,
    *,
    page_id: str,
    page_token: str,
) -> bool:
    """DELETE `/{page_id}/subscribed_apps`. Removes the leadgen
    subscription for this Page; deliveries stop within Meta's normal
    propagation window (a few seconds). Caller should follow with
    `delete_page_token` to clear the cached Page token.

    Returns True on Meta's `{"success": true}` response."""
    body = await client.delete(
        f"/{page_id}/subscribed_apps",
        access_token=page_token,
    )
    return bool(body.get("success"))


# --- Page-token cache (Step 5) --------------------------------------------


async def upsert_page_token(
    session: AsyncSession,
    *,
    org_id: uuid.UUID,
    integration_id: uuid.UUID,
    page_id: str,
    page_name: str | None,
    page_token: str,
) -> MetaPageToken:
    """Cache the Page-scoped access_token in `meta_page_tokens` so the
    Step-5 webhook worker doesn't need to re-fetch `/me/accounts` on
    every delivery. UPSERT semantics — re-subscribing the same Page
    rotates the cached token in place.

    Token stored as Fernet ciphertext via Step 1's `crypto.encrypt`."""
    existing = (
        await session.execute(
            select(MetaPageToken)
            .where(MetaPageToken.integration_id == integration_id)
            .where(MetaPageToken.page_id == page_id)
        )
    ).scalar_one_or_none()
    enc = encrypt(page_token)
    now = datetime.now(UTC)
    if existing is None:
        row = MetaPageToken(
            org_id=org_id,
            integration_id=integration_id,
            page_id=page_id,
            page_name=page_name,
            page_token_enc=enc,
            updated_at=now,
        )
        session.add(row)
    else:
        existing.page_token_enc = enc
        existing.page_name = page_name
        existing.updated_at = now
        row = existing
    await session.commit()
    await session.refresh(row)
    return row


async def delete_page_token(
    session: AsyncSession,
    *,
    integration_id: uuid.UUID,
    page_id: str,
) -> bool:
    """Drop the cached Page token after `unsubscribe_page` succeeds.
    Returns True if a row was removed, False if nothing was cached
    (idempotent — safe to call on never-subscribed Pages)."""
    row = (
        await session.execute(
            select(MetaPageToken)
            .where(MetaPageToken.integration_id == integration_id)
            .where(MetaPageToken.page_id == page_id)
        )
    ).scalar_one_or_none()
    if row is None:
        return False
    await session.delete(row)
    await session.commit()
    return True


async def find_page_token(
    client: MetaGraphClient,
    *,
    page_id: str,
) -> str | None:
    """Look up the access_token for a specific page id by paging
    through `/me/accounts`. Returns None if the user no longer
    manages that page (could happen if Pages were transferred out of
    their account between subscribe and a follow-up call).

    Used by router endpoints that take a `page_id` path param — the
    Owner clicked "subscribe to Page X"; we need X's token to act."""
    pages = await list_pages(client)
    for page in pages:
        if page.page_id == page_id:
            return page.access_token
    return None


# --- Messenger + Instagram messaging subscriptions ------------------------


_MESSAGING_FIELDS = (
    "messages,messaging_postbacks,message_reactions,message_reads,message_echoes"
)


async def subscribe_page_messaging(
    client: MetaGraphClient,
    *,
    page_id: str,
    page_token: str,
) -> bool:
    """Extend an already-subscribed Page's ``subscribed_fields`` to
    include the Messenger + IG messaging events.

    POST ``/{page_id}/subscribed_apps`` with the combined
    ``subscribed_fields`` list (Meta's endpoint is additive — passing
    only the new fields would drop ``leadgen``). Returns True on
    Meta's ``{"success": true}``. Idempotent: re-subscribing the same
    fields is a no-op on Meta's side.
    """
    body = await client.post(
        f"/{page_id}/subscribed_apps",
        params={"subscribed_fields": f"leadgen,{_MESSAGING_FIELDS}"},
        access_token=page_token,
    )
    return bool(body.get("success"))


async def unsubscribe_page_messaging(
    client: MetaGraphClient,
    *,
    page_id: str,
    page_token: str,
) -> bool:
    """Narrow the Page's subscription back to ``leadgen`` only. Meta
    doesn't offer a way to remove individual fields; the workaround is
    POST-with-just-leadgen (which replaces the list)."""
    body = await client.post(
        f"/{page_id}/subscribed_apps",
        params={"subscribed_fields": "leadgen"},
        access_token=page_token,
    )
    return bool(body.get("success"))


@dataclass(frozen=True, slots=True)
class InstagramBusinessAccount:
    """The IG Business Account linked to a Facebook Page. Populated
    from ``GET /{page_id}?fields=instagram_business_account{id,name}``.
    ``None`` when no IG account is linked."""

    ig_business_id: str
    username: str | None


async def get_linked_instagram_account(
    client: MetaGraphClient,
    *,
    page_id: str,
    page_token: str,
) -> InstagramBusinessAccount | None:
    """Return the IG Business Account linked to this Facebook Page, if
    any. Callers use the ``ig_business_id`` as a lookup key when
    persisting a second ``tbl_meta_page_tokens`` row so incoming IG
    webhook events (which arrive with ``entry.id = ig_business_id``)
    can find the same Page token.
    """
    body = await client.get(
        f"/{page_id}",
        params={"fields": "instagram_business_account{id,username}"},
        access_token=page_token,
    )
    account = body.get("instagram_business_account")
    if not isinstance(account, dict):
        return None
    ig_id = account.get("id")
    if not ig_id:
        return None
    return InstagramBusinessAccount(
        ig_business_id=str(ig_id),
        username=(str(account["username"]) if account.get("username") else None),
    )


__all__ = [
    "InstagramBusinessAccount",
    "MetaLeadForm",
    "MetaPage",
    "delete_page_token",
    "find_page_token",
    "get_linked_instagram_account",
    "list_lead_forms_for_page",
    "list_pages",
    "subscribe_page",
    "subscribe_page_messaging",
    "unsubscribe_page",
    "unsubscribe_page_messaging",
    "upsert_page_token",
]
